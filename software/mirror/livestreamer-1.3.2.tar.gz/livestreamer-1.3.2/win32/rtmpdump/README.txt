
This is a RTMPdump Win32 static build by Steven Penny.

Steven�s Blog: http://svnpenn.blogspot.com


RTMPdump version 2.4 git-6230845 2011-9-25

The source code for this RTMPdump build can be found at:
	http://rtmpdump.mplayerhq.hu
	http://repo.or.cz/w/rtmpdump.git

This version of RTMPdump was built on:
	Windows 7 Ultimate Service Pack 1

These binaries were built with:

	MinGW 0.3-alpha-2.1
	GCC 4.6.1-2
	Bash 3.1.17-4
	Make 3.81-3
	ZLib 1.2.5
	PolarSSL 1.0.0